# SER-502-Compiler

**Flow diagram of compiler**
![alt text](https://github.com/sarvanshprasher/SER502-Spring2020-Team20/blob/master/Flow%20Diagram.jpg)
